## 1.0.0
- Initial Release

## 1.1.0
- Change Package Name
- Add Meta SEO
- Add Semantics
- Add Arrow Key Listener

## 1.2.0
- Add SEO wrapper
- Fix scope auto focus

## 1.3.0
- Add Robot.txt
- Add Sitemap.xml

## 1.4.0
- Update index.html

## 1.4.1
- Add github link